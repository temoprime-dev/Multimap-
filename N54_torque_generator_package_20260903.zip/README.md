# N54 Torque-Based Generator — output package (2026-09-03)

Все три стейджа сгенерированы `torque_based_tune_sim.py` из `I8A0S_original.bin`, byte-exact verified (запись -> обратное чтение -> сверка + проверка "ничего лишнего не изменилось за пределами известных адресов").

## Файлы

- `I8A0S_original.bin` — сток-референс (для дифа/сравнения в TunerPro)
- `I8A0S_torque_stage1_output.bin` — 465 байт изменено, 7 таблиц (включая Burble, см. ниже)
- `I8A0S_torque_stage2_output.bin` — 343 байта изменено, 6 таблиц
- `I8A0S_torque_stage2plus_output.bin` — 343 байта изменено, 6 таблиц
- `I8A0S.xdf` — community XDF (для открытия любого из бинарников в TunerPro и сверки значений визуально)

## Таблица настроек по стейджам

| Параметр | Сток | Stage 1 | Stage 2 | Stage 2+ |
|---|---|---|---|---|
| Requested Torque Limit (Driver) | 295 ft-lb плато | ×1.30 → ~384 | ×1.45 → ~428 | ×1.60 → ~472 |
| Load to Torque Limit (×3 копии) | — | ×1.12 (Load 105-140 only) | то же | то же |
| Torque Monitor Ceiling | 410-462 ft-lb | не тронуто | плоско 1492 ft-lb | плоско 1492 ft-lb |
| Boost Ceiling | 1.28 bar | 1.28 bar | 1.40 bar | 1.50 bar |
| Boost Limit Multiplier | 2.30→1.71 | плоско 2.30 | плоско 2.60 | плоско 3.00 |
| WGDC Limit | 57% | 80% | 92% | 100% |
| **Burble** | — | **включён** (см. ниже) | нет | нет |

Не тронуто ни в одном стейдже (осознанно, не пробел — см. `project_n54_torque_based_generator.md`): WGDC Base/PID, Timing (Main), Fuel (Main).

## Burble (только в Stage 1 файле)

Реальные сток-таблицы trailing-throttle (не MHD-инжект — внутренние Siemens-имена `ip_iga_min_n_maf_pu_h_rng`/`ip_t_min_pu__n__tco` подтверждены в XDF):
- **Burble Ignition Timing** (`0x54A30`, 6×8 FuelMass×RPM) — retard "floor" до минимум -16° (было от -1° до -30°, ячейки уже агрессивнее -16° не трогались)
- **Burble Duration Normal/Sport** (`0x55FEC`/`0x5604C`) — длительность поднята минимум до 0.8с (было ~0.25-0.5с)
- Предусловие `Disable Tq Reduction by Ign` (`0x42C33`) уже 0 в стоке — не трогалось, только сверено
- `Min Burble RPM` (`0x4D568`) уже 0 (без ограничения по оборотам) — не трогалось

**⚠️ Реальный риск**: ускоряет износ катализатора и лямбда/O2-датчиков, задействует калибровку Cat Protection Mode. В реальном продукте (Tune-экран) это гейтится обязательным чекбоксом согласия + логируемым событием — в этом offline-файле такого гейта нет, это просто патч.

## Как проверять

Открыть любой `I8A0S_torque_stage*_output.bin` в TunerPro с `I8A0S.xdf`, сравнить с `I8A0S_original.bin` — значения таблиц выше должны совпадать с колонкой соответствующего стейджа. Ни один байт вне 5-6 указанных таблиц измениться не должен.
