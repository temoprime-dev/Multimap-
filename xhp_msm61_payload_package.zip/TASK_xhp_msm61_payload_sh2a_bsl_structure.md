# TASK for Arena — help identify/verify a 30KB TCU payload (2026-09-02)

## File

`C:\temp\xhp_resources\joaV_decoded\msm61_unlock_block_0x800.bin` (attached/sent separately) — 30,720 bytes, decoded from an Intel-HEX resource embedded in xHP Flashtool's `UNI_Flash.dll`, real target address range `0x000800`–`0x007FFF`.

## Context

We're trying to identify what this payload is. It comes from a routine called `PerformMsm61UnlockAndPrepareRouting` inside xHP's TCU (transmission) flashing engine. **Priority scope: BMW ZF6HP and ZF8HP transmissions only — NOT the DCT (GS7D36SG), that's out of scope for us right now.**

Per your earlier chip-architecture research, the relevant candidates are:
- ZF6HP → Freescale/NXP **MPC562** (PowerPC e200, Qorivva family)
- ZF8HP Gen1/Gen2 → Renesas **SH7254x** (SuperH SH-2A core)
- ZF8HP Gen3 → Infineon **TC275** (TriCore TC2xx) — out of scope, this generation is too new for what we're after

We locally disassembled this payload against 5 architecture/tool combinations (TriCore via radare2 and Ghidra, PowerPC classic via radare2, PowerPC VLE via Ghidra, PowerPC mpc55xx via IDA Pro) — **all five gave the same signature: a short burst of plausible-looking instructions (3-30) then a hard breakdown into undecodable bytes.** That's the statistical fingerprint of testing a real CPU decoder against data that ISN'T plain executable code for that architecture (encrypted, compressed, or just the wrong ISA). We have NOT yet properly tested Renesas SH-2A with a real decompiler-quality pass (only a quick, inconclusive eyeball check) — that's in progress locally right now.

## What we'd like from you

1. **If you have any way to inspect the binary file's structure yourself** (hex/entropy view, known-format detection, whatever tools you have): does anything about it match a known Renesas SH-2A or Freescale MPC5xx bootloader/BSL image format? Specifically we're looking for: a recognizable reset/vector table at the start, a known magic number or header signature, or a checksum/CRC footer convention documented for either chip family's boot ROM.

2. **Web research**: is there a publicly documented BSL (boot-strap-loader) image format or header structure for **Renesas SH7254x** (used in ZF8HP Gen1/Gen2 TCUs) or **Freescale MPC562** (ZF6HP TCUs)? We want to know what a legitimate boot-sector image for either chip is supposed to look like structurally (vector table layout, header fields, checksum scheme) so we can check our payload against that shape, independent of whether it disassembles cleanly (it might be encrypted, in which case structure/header bytes might still be visible even if the body isn't).

3. Is there any public reference dump, teardown, or leaked firmware image for **ZF6HP or ZF8HP (Gen1/Gen2) TCU boot code** we could diff our payload's header/trailer bytes against?

## What NOT to worry about

Don't research the BMW DCT (GS7D36SG) chip — that's a different transmission family we've deprioritized for now, only 6HP/8HP matters here.

## How to report back

Plain markdown, cite sources for any claims about the BSL/bootloader format. A clear "nothing public on this" is a fine and useful answer if that's what you find — we're not expecting this to necessarily be a solved/documented topic.
