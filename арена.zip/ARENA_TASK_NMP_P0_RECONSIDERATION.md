# Arena/Kimi update: P0 probe may not mean what we thought — two-frame test also fast-aborts

## What we tried

Following up on the P0 result (fast `NET-0014 CONNECTION ABORTED` instead of
slow `NET-0009 TIMEOUT`), we tested the "two-frame reply" hypothesis: sent
TWO complete NMP frames back to back as the reply to call #14 — frame A
(82 bytes, empty ACK matching call 11's shape) immediately followed by
frame B (98 bytes, same shape but carrying our real 16-byte KWP payload) —
then did the same P0 half-close (`Shutdown(SocketShutdown.Send)`)
immediately after both writes.

**Result: still an immediate `NET-0014 CONNECTION ABORTED`**, same fast
timing as every single-frame variant. Sending nearly triple the bytes
(180 vs ~68-98) made no difference to the fast-abort behavior.

## Reconsidering what P0 actually tells us

Given that MORE bytes didn't change the outcome at all, we think our
original interpretation of the P0 result ("client blocked in `recv()`
waiting for additional bytes to complete parsing THIS reply, so it's
under-sized") may have been wrong. An alternative, arguably more consistent
explanation: the client keeps the TCP connection open expecting to
potentially use it again for a FUTURE call (i.e. it doesn't necessarily
close the connection right after processing one reply — the connection may
be meant to persist across the whole `apiJob` session, or at least until
some higher-level completion). If so, ANY premature `FIN` from us —
regardless of whether our actual reply content/framing was correct — would
produce some kind of abrupt-disconnection error, simply because the
connection was still "supposed to" be open from the client's perspective.
That would make `NET-0014` after a P0 shutdown uninformative about frame
completeness specifically, and we may have chased a red herring for the
last two test rounds.

## Where we actually stand

- We have a real, working full round-trip through call #13 (13 real
  request/reply pairs, all confirmed accepted by an unmodified real
  `Tool32.exe`).
- Call #14 (`SENDRECEIVE`, the actual diagnostic exchange) is the one call
  we cannot get right. Without the P0 probe, every reply variant we've
  tried (varying scalar-result count 0-3, varying the literal "count" field
  value, varying payload content empty-vs-real-data, and now single-vs-
  two-frame) produces the SAME slow `NET-0009 TIMEOUT` with no `call #15`
  ever sent by the client.
- We no longer have a confident read on whether that timeout means "still
  structurally wrong" or something else (e.g. the reply IS being accepted
  but the client is doing local/application-layer validation — like
  actually checking our KWP checksum, SID echo, or DID value against
  something specific — that fails silently without protocol-level
  rejection, then just... doesn't proceed until its own top-level job
  timeout fires).

## What would actually resolve this

We think we've exhausted cheap black-box probing. The two paths forward
that seem likely to actually work:

1. **Static/dynamic analysis of the real binaries** (`ebas32.dll`,
   `XRemot32.dll`, `nettcp32.dll`, `ifhsrv32.exe` — all available locally,
   real EDIABAS 7.3.0/Softing AG files from a legitimately owned/installed
   toolset) to directly find the `SENDRECEIVE`/`0x001d` reply-handling
   logic and read off the exact expected layout, rather than continuing to
   infer it from black-box probing. If you (Kimi/Arena) can work from the
   files directly (we can upload them), that would let you give us a
   byte-exact answer instead of another candidate to test.
2. **A genuine reference reply**, captured from a real `ifhsrv32.exe` that
   actually reaches the `SENDRECEIVE` stage (even if it ultimately times out
   waiting for a real ECU — we just need to see what a CORRECTLY-FRAMED
   `SENDRECEIVE` reply/status update looks like on the wire, success or
   failure). We tried `Simulation=1` with the bundled `OBD.sim` hoping this
   would let a real server past the earlier hardware-rejection issue
   (`SETECUCOMM` failing due to `OBD32.dll` not recognizing our generic FTDI
   adapter) without needing real/compatible hardware — but that didn't work;
   `SETECUCOMM` still failed identically even with simulation enabled (per
   local `IFH.trc`). If there's a way to make EDIABAS's simulation mode
   actually take effect earlier in the chain (maybe a different
   `HW-Interface`/config combination, or a way to simulate at the
   `SETECUCOMM` level specifically), that would unblock getting real ground
   truth without needing genuine BMW-recognized hardware.

We're open to trying more candidate byte layouts if you have a strong new
lead, but wanted to flag that black-box iteration alone has plateaued —
further progress likely needs either the actual disassembled logic or a
real reference capture.
